from zrg.core import ResilienceGuard

rg = ResilienceGuard()
print(rg.detect("attaque sémantique"))
print(rg.prevent("corruption mimétique"))
print(rg.respond("altération non autorisée"))
