from zrg.core import ResilienceGuard

def test_detect():
    rg = ResilienceGuard()
    assert "Analyse" in rg.detect("intrusion")
