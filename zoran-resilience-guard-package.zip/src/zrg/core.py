class ResilienceGuard:
    def __init__(self):
        pass

    def detect(self, data):
        return f"Analyse des données : {data}"

    def prevent(self, threat):
        return f"Prévention activée contre : {threat}"

    def respond(self, incident):
        return f"Réponse à l'incident : {incident}"
